begin;

-- 1) activity_events: agregar lead_id
alter table public.activity_events
  add column if not exists lead_id uuid;

-- (opcional pero recomendado) FK suave sin cascade
do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'activity_events_lead_id_fkey'
  ) then
    alter table public.activity_events
      add constraint activity_events_lead_id_fkey
      foreign key (lead_id) references public.leads(id)
      on delete set null;
  end if;
end $$;

-- 2) Índice compuesto para "última actividad por lead"
create index if not exists activity_events_actor_lead_recorded_at_idx
  on public.activity_events (actor_user_id, lead_id, recorded_at desc);

-- 3) Actualizar RPC get_today_focus para usar lead_id + ignorar eventos void
create or replace function public.get_today_focus(p_limit integer default 25)
returns table (
  lead_id uuid,
  full_name text,
  stage_id uuid,
  stage_name text,
  sla_status text,
  days_in_stage int,
  entered_stage_at timestamptz,
  last_activity_at timestamptz,
  priority_score int,
  reason text
)
language sql
security definer
set search_path = public
as $$
with base as (
  select
    a.lead_id,
    l.full_name,
    l.stage_id,
    s.name as stage_name,
    a.sla_status,
    a.days_in_stage,
    a.entered_stage_at,
    (
      select max(e.recorded_at)
      from public.activity_events e
      where e.actor_user_id = auth.uid()
        and e.lead_id = l.id
        and coalesce(e.is_void, false) = false
    ) as last_activity_at
  from public.v_lead_sla_alerts a
  join public.leads l on l.id = a.lead_id
  join public.pipeline_stages s on s.id = l.stage_id
  where l.owner_user_id = auth.uid()
),
scored as (
  select
    *,
    (
      case
        when sla_status = 'breach' then 1000
        when sla_status = 'warn' then 700
        else 0
      end
      + least(days_in_stage, 60) * 5
      + case
          when last_activity_at is null then 200
          when last_activity_at < (now() - interval '3 days') then 150
          when last_activity_at < (now() - interval '1 day') then 50
          else 0
        end
    )::int as priority_score,
    case
      when sla_status = 'breach' then 'SLA vencido en etapa'
      when sla_status = 'warn' then 'SLA por vencer'
      when last_activity_at is null then 'Sin actividad registrada'
      when last_activity_at < (now() - interval '3 days') then 'Sin actividad en 3+ días'
      when last_activity_at < (now() - interval '1 day') then 'Sin actividad desde ayer'
      else 'Seguimiento recomendado'
    end as reason
  from base
)
select
  lead_id,
  full_name,
  stage_id,
  stage_name,
  sla_status,
  days_in_stage,
  entered_stage_at,
  last_activity_at,
  priority_score,
  reason
from scored
order by priority_score desc, last_activity_at nulls first, entered_stage_at asc
limit greatest(1, p_limit);
$$;

grant execute on function public.get_today_focus(integer) to authenticated;

commit;
