/**
 * Tabla compartida para leaderboard semanal de equipo
 * Incluye sorting, filtros e insights accionables
 */

import { useState, useMemo, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../../lib/supabaseClient'
import type { AdvisorWeekStats } from '../../../pages/owner/utils/ownerDashboardHelpers'
import type { Advisor } from '../../../pages/owner/utils/ownerDashboardHelpers'
import {
  calculateAdvisorInsight,
  getRiskReasonInfo,
} from '../dashboard/teamDashboardInsights'
import { buildTodayPlanForAdvisor } from '../dashboard/todayActionPlan'
import {
  getPrevWeekRangeLocal,
  fetchEventsForRange,
} from '../dashboard/weekCompareHelpers'
import {
  computeAdvisorWeekStats,
} from '../../../pages/owner/utils/ownerDashboardHelpers'

export interface TeamWeeklyLeaderboardTableProps {
  weekStats: AdvisorWeekStats[]
  weeklyTarget: number
  weeklyDays: number
  weekStartLocal: string
  weekEndLocal: string
  todayLocal: string
  advisorIds: string[]
  scoresMap: Map<string, number>
  onAdvisorClick?: (advisorId: string) => void
  defaultSort?: 'points' | 'projection' | 'status' | 'required'
  getAdvisorName: (advisor: Advisor) => string
  getStatusInfo: (status: AdvisorWeekStats['status']) => {
    label: string
    color: string
    bg: string
  }
}

type SortField = 'points' | 'projection' | 'status' | 'required'
type SortDirection = 'asc' | 'desc'

export function TeamWeeklyLeaderboardTable({
  weekStats,
  weeklyTarget,
  weeklyDays,
  weekStartLocal,
  weekEndLocal,
  todayLocal,
  advisorIds,
  scoresMap,
  onAdvisorClick,
  defaultSort = 'points',
  getAdvisorName,
  getStatusInfo,
}: TeamWeeklyLeaderboardTableProps) {
  const navigate = useNavigate()
  const [sortField, setSortField] = useState<SortField>(defaultSort)
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc')
  const [showOnlyAtRisk, setShowOnlyAtRisk] = useState(false)
  const [prevWeekPointsMap, setPrevWeekPointsMap] = useState<Map<string, number>>(new Map())
  const [loadingPrevWeek, setLoadingPrevWeek] = useState(false)

  // Cargar datos de semana anterior (1 query para todo el equipo, sin N+1)
  useEffect(() => {
    if (advisorIds.length === 0) {
      setPrevWeekPointsMap(new Map())
      return
    }

    let mounted = true

    const loadPrevWeek = async () => {
      setLoadingPrevWeek(true)
      try {
        const { prevWeekStartLocal, prevWeekEndLocal, prevNextWeekStartLocal } = getPrevWeekRangeLocal(weekStartLocal)
        const prevEvents = await fetchEventsForRange({
          supabase,
          advisorIds,
          fromYmdInclusive: prevWeekStartLocal,
          toYmdExclusive: prevNextWeekStartLocal,
        })

        if (!mounted) return

        // Calcular stats de semana anterior para cada advisor
        const map = new Map<string, number>()
        for (const advisorId of advisorIds) {
          const prevStats = computeAdvisorWeekStats(
            prevEvents,
            advisorId,
            scoresMap,
            weeklyTarget,
            weeklyDays,
            todayLocal,
            prevWeekStartLocal,
            prevWeekEndLocal
          )
          map.set(advisorId, prevStats?.weekPoints ?? 0)
        }

        if (mounted) {
          setPrevWeekPointsMap(map)
        }
      } catch (err) {
        console.error('[TeamWeeklyLeaderboardTable] Error al cargar semana anterior:', err)
        if (mounted) {
          setPrevWeekPointsMap(new Map())
        }
      } finally {
        if (mounted) {
          setLoadingPrevWeek(false)
        }
      }
    }

    loadPrevWeek()

    return () => {
      mounted = false
    }
  }, [advisorIds, weekStartLocal, weeklyTarget, weeklyDays, todayLocal, scoresMap])

  // Calcular insights y planes del día para cada stat
  const statsWithInsights = useMemo(() => {
    return weekStats.map((stat) => {
      const insight = calculateAdvisorInsight(stat, weeklyTarget, weeklyDays, weekStartLocal, todayLocal)
      const todayPlan = buildTodayPlanForAdvisor({
        requiredDailyAvg: insight.requiredDailyAvg,
        riskReason: insight.riskReason,
        scoresMap,
      })
      return {
        stat,
        insight,
        todayPlan,
      }
    })
  }, [weekStats, weeklyTarget, weeklyDays, weekStartLocal, todayLocal, scoresMap])

  // Filtrar por riesgo si está activo
  const filteredStats = useMemo(() => {
    if (!showOnlyAtRisk) return statsWithInsights
    return statsWithInsights.filter(
      (item) => item.stat.status === 'at_risk' || item.insight.riskReason !== 'on_track'
    )
  }, [statsWithInsights, showOnlyAtRisk])

  // Ordenar
  const sortedStats = useMemo(() => {
    const sorted = [...filteredStats].sort((a, b) => {
      let aValue: number | string
      let bValue: number | string

      switch (sortField) {
        case 'points':
          aValue = a.stat.weekPoints
          bValue = b.stat.weekPoints
          break
        case 'projection':
          aValue = a.stat.projection
          bValue = b.stat.projection
          break
        case 'status':
          // Ordenar por status: at_risk < on_track < completed < excellent
          const statusOrder: Record<AdvisorWeekStats['status'], number> = {
            at_risk: 0,
            on_track: 1,
            completed: 2,
            excellent: 3,
          }
          aValue = statusOrder[a.stat.status]
          bValue = statusOrder[b.stat.status]
          break
        case 'required':
          aValue = a.insight.requiredDailyAvg
          bValue = b.insight.requiredDailyAvg
          break
        default:
          aValue = a.stat.weekPoints
          bValue = b.stat.weekPoints
      }

      if (typeof aValue === 'number' && typeof bValue === 'number') {
        return sortDirection === 'asc' ? aValue - bValue : bValue - aValue
      }
      return sortDirection === 'asc'
        ? String(aValue).localeCompare(String(bValue))
        : String(bValue).localeCompare(String(aValue))
    })

    return sorted
  }, [filteredStats, sortField, sortDirection])

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDirection('desc')
    }
  }

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return null
    return sortDirection === 'asc' ? '↑' : '↓'
  }

  const handleRowClick = (advisorId: string) => {
    if (onAdvisorClick) {
      onAdvisorClick(advisorId)
    }
  }

  const handlePlanClick = (e: React.MouseEvent, advisorId: string) => {
    e.stopPropagation() // Evitar que se active el click de la fila
    navigate(`/manager/advisor/${advisorId}?focus=fulfillment`)
  }

  // Helper para formatear delta
  const formatDelta = (current: number, prev: number | null): string => {
    if (prev === null) return '—'
    const delta = current - prev
    if (delta > 0) return `↑ +${Math.round(delta)}`
    if (delta < 0) return `↓ ${Math.round(delta)}`
    return '→ 0'
  }

  return (
    <div className="card p-0 overflow-hidden">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Leaderboard Semanal</h2>
            <p className="text-xs text-muted mt-1">Semana actual: {weekStartLocal} - {weekEndLocal}</p>
          </div>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input
              type="checkbox"
              checked={showOnlyAtRisk}
              onChange={(e) => setShowOnlyAtRisk(e.target.checked)}
              className="rounded"
            />
            <span className="text-muted">Solo en riesgo</span>
          </label>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-bg border-b border-border">
            <tr>
              <th
                className="text-left py-3 px-4 text-xs font-semibold text-muted uppercase cursor-pointer hover:bg-black/5"
                onClick={() => handleSort('points')}
              >
                Asesor <SortIcon field="points" />
              </th>
              <th
                className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase cursor-pointer hover:bg-black/5"
                onClick={() => handleSort('points')}
              >
                Pts <SortIcon field="points" />
              </th>
              <th className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase">%</th>
              <th
                className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase cursor-pointer hover:bg-black/5"
                onClick={() => handleSort('projection')}
              >
                Proyección <SortIcon field="projection" />
              </th>
              <th className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase">Falta</th>
              <th
                className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase cursor-pointer hover:bg-black/5"
                onClick={() => handleSort('required')}
              >
                Requiere/día <SortIcon field="required" />
              </th>
              <th className="text-center py-3 px-4 text-xs font-semibold text-muted uppercase">Hoy</th>
              <th className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase">
                Δ vs ant.
              </th>
              <th
                className="text-center py-3 px-4 text-xs font-semibold text-muted uppercase cursor-pointer hover:bg-black/5"
                onClick={() => handleSort('status')}
              >
                Estado <SortIcon field="status" />
              </th>
              <th className="text-center py-3 px-4 text-xs font-semibold text-muted uppercase">Acción</th>
            </tr>
          </thead>
          <tbody>
            {sortedStats.length === 0 ? (
              <tr>
                <td colSpan={10} className="text-center py-12 px-4 text-muted">
                  {showOnlyAtRisk ? 'No hay asesores en riesgo' : 'No hay asesores registrados'}
                </td>
              </tr>
            ) : (
              sortedStats.map(({ stat, insight, todayPlan }) => {
                const statusInfo = getStatusInfo(stat.status)
                const riskInfo = getRiskReasonInfo(insight.riskReason)
                const isClickable = !!onAdvisorClick
                const prevPoints = prevWeekPointsMap.get(stat.advisor.user_id) ?? null
                const delta = formatDelta(stat.weekPoints, prevPoints)

                return (
                  <tr
                    key={stat.advisor.user_id}
                    className={`border-b border-border hover:bg-bg ${isClickable ? 'cursor-pointer' : ''}`}
                    onClick={() => isClickable && handleRowClick(stat.advisor.user_id)}
                  >
                    <td className="py-3 px-4 font-medium">{getAdvisorName(stat.advisor)}</td>
                    <td className="py-3 px-4 text-right font-semibold">{Math.round(stat.weekPoints)}</td>
                    <td className="py-3 px-4 text-right text-muted">{Math.round(stat.percentOfTarget)}%</td>
                    <td className="py-3 px-4 text-right text-muted">
                      {stat.daysWithActivity > 0 ? Math.round(stat.projection) : '—'}
                    </td>
                    <td className="py-3 px-4 text-right text-muted">
                      {insight.pointsRemaining > 0 ? Math.round(insight.pointsRemaining) : '—'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      {insight.requiredDailyAvg > 0 ? (
                        <span className="font-medium text-amber-600">{Math.round(insight.requiredDailyAvg)}</span>
                      ) : (
                        <span className="text-muted">—</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div
                        className="group relative inline-block cursor-help"
                        title={
                          todayPlan.requiredDailyAvgPoints > 0
                            ? `Requerido: ${Math.round(todayPlan.requiredDailyAvgPoints)} pts\n` +
                              `Distribución: ${todayPlan.items.map((i) => `${i.units} ${i.metric_key} (${i.pointsPerUnit} pts/u)`).join(', ')}` +
                              (todayPlan.skippedMetrics.length > 0
                                ? `\nOmitidas: ${todayPlan.skippedMetrics.join(', ')}`
                                : '')
                            : 'Mantener ritmo actual'
                        }
                      >
                        <span className={`text-xs ${todayPlan.isKickstart ? 'text-red-600 font-semibold' : todayPlan.requiredDailyAvgPoints > 0 ? 'text-text' : 'text-muted'}`}>
                          {todayPlan.label}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right text-muted">
                      {loadingPrevWeek ? (
                        <span className="text-xs">...</span>
                      ) : (
                        <span className={`text-xs font-medium ${
                          prevPoints === null ? 'text-muted' :
                          stat.weekPoints > prevPoints ? 'text-green-600' :
                          stat.weekPoints < prevPoints ? 'text-red-600' :
                          'text-muted'
                        }`}>
                          {delta}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center space-x-1">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${statusInfo.bg} ${statusInfo.color}`}>
                        {statusInfo.label}
                      </span>
                      {insight.riskReason !== 'on_track' && (
                        <span className={`px-2 py-1 rounded text-xs font-medium ${riskInfo.bg} ${riskInfo.color}`}>
                          {riskInfo.label}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {todayPlan.requiredDailyAvgPoints > 0 && (
                        <button
                          onClick={(e) => handlePlanClick(e, stat.advisor.user_id)}
                          className="text-xs text-primary hover:underline"
                          title="Ver plan de hoy"
                        >
                          Plan de hoy
                        </button>
                      )}
                    </td>
                  </tr>
                )
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
