import { useEffect, useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useUserRole } from '../../shared/hooks/useUserRole'
import { useAuth } from '../../shared/auth/AuthProvider'
import { useTeamOkrDashboard } from '../../modules/okr/dashboard/useTeamOkrDashboard'
import { useDashboardSnapshot } from '../../modules/okr/dashboard/useDashboardSnapshot'
import { TeamWeeklyLeaderboardTable } from '../../modules/okr/components/TeamWeeklyLeaderboardTable'
import { TeamConsistencyTable } from '../../modules/okr/components/TeamConsistencyTable'
import { buildTeamAlerts, getAlertSeverityInfo } from '../../modules/okr/dashboard/teamAlerts'
import {
  type Advisor,
  type AdvisorWeekStats,
} from '../owner/utils/ownerDashboardHelpers'
import { calculateAdvisorInsight } from '../../modules/okr/dashboard/teamDashboardInsights'

const IS_DEV = import.meta.env.DEV

export function ManagerDashboardPage() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const { role, loading: roleLoading } = useUserRole()
  const [toastMessage, setToastMessage] = useState<string | null>(null)

  const isManager = role === 'manager' || role === 'owner'

  // Usar hook compartido para datos del dashboard
  const {
    weekStats,
    historyStats,
    dailyTarget,
    weeklyDays,
    weeklyTarget,
    weekStartLocal,
    weekEndLocal,
    todayLocal,
    advisorIds,
    scoresMap,
    loading,
    error,
    reload: loadData,
  } = useTeamOkrDashboard({
    mode: 'manager',
    managerUserId: user?.id,
  })

  const { copySnapshot } = useDashboardSnapshot()

  useEffect(() => {
    if (!roleLoading && !isManager) {
      navigate('/', { replace: true })
    }
  }, [isManager, roleLoading, navigate])

  // Calcular insights para resumen mejorado
  const insights = useMemo(() => {
    const statsWithInsights = weekStats.map((stat) => ({
      stat,
      insight: calculateAdvisorInsight(stat, weeklyTarget, weeklyDays, weekStartLocal, todayLocal),
    }))

    const noActivity = statsWithInsights.filter((item) => item.insight.riskReason === 'no_activity').length
    const lowRhythm = statsWithInsights.filter((item) => item.insight.riskReason === 'low_rhythm').length
    const onTrack = statsWithInsights.filter((item) => item.insight.riskReason === 'on_track').length

    const totalPoints = weekStats.reduce((sum, s) => sum + s.weekPoints, 0)
    const avgPoints = weekStats.length > 0 ? Math.round(totalPoints / weekStats.length) : 0

    return {
      noActivity,
      lowRhythm,
      onTrack,
      avgPoints,
    }
  }, [weekStats, weeklyTarget, weeklyDays, weekStartLocal, todayLocal])

  // Calcular resumen de estados
  const summary = useMemo(() => {
    const atRisk = weekStats.filter((s) => s.status === 'at_risk').length
    const onTrack = weekStats.filter((s) => s.status === 'on_track').length
    const completed = weekStats.filter((s) => s.status === 'completed').length
    const excellent = weekStats.filter((s) => s.status === 'excellent').length

    return { atRisk, onTrack, completed, excellent, total: weekStats.length }
  }, [weekStats])

  // Obtener nombre del asesor
  const getAdvisorName = (advisor: Advisor): string => {
    if (advisor.full_name && advisor.full_name.trim()) {
      return advisor.full_name.trim()
    }
    if (advisor.display_name && advisor.display_name.trim()) {
      return advisor.display_name.trim()
    }
    return `Usuario ${advisor.user_id.slice(0, 8)}`
  }

  // Obtener color y label del estado
  const getStatusInfo = (status: AdvisorWeekStats['status']) => {
    switch (status) {
      case 'excellent':
        return { label: '🔥', color: 'text-purple-600', bg: 'bg-purple-50' }
      case 'completed':
        return { label: '✅', color: 'text-green-600', bg: 'bg-green-50' }
      case 'on_track':
        return { label: 'En camino', color: 'text-green-600', bg: 'bg-green-50' }
      case 'at_risk':
        return { label: 'En riesgo', color: 'text-red-600', bg: 'bg-red-50' }
    }
  }

  const handleAdvisorClick = (advisorId: string) => {
    navigate(`/manager/advisor/${advisorId}`)
  }

  const handleCopySnapshot = async () => {
    const success = await copySnapshot(
      'manager',
      weekStartLocal,
      weekEndLocal,
      weeklyTarget,
      dailyTarget,
      weeklyDays,
      advisorIds
    )
    if (success) {
      setToastMessage('Snapshot copiado')
      setTimeout(() => setToastMessage(null), 2000)
    }
  }

  // Calcular alertas del equipo
  const teamAlerts = useMemo(() => {
    return buildTeamAlerts({
      weekStats,
      historyStats,
      weeklyTarget,
    })
  }, [weekStats, historyStats, weeklyTarget])

  if (roleLoading || loading) {
    return (
      <div className="text-center p-8">
        <span className="text-muted">Cargando...</span>
      </div>
    )
  }

  if (!isManager) {
    return (
      <div className="text-center p-8">
        <div className="text-lg font-semibold mb-2">No autorizado</div>
        <div className="text-sm text-muted">Solo los managers pueden acceder a esta vista.</div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="card p-4 bg-red-50 border border-red-200">
        <div className="text-sm text-red-700">{error}</div>
        <button onClick={loadData} className="btn btn-primary mt-3 text-sm">
          Reintentar
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">Dashboard Manager</h1>
          <p className="text-sm text-muted">Tu equipo: desempeño semanal y consistencia histórica</p>
        </div>
        {IS_DEV && (
          <button
            onClick={handleCopySnapshot}
            className="px-3 py-1.5 text-xs border border-border rounded bg-bg text-text hover:bg-black/5 transition-colors"
          >
            Copiar snapshot
          </button>
        )}
      </div>

      {/* Toast para snapshot */}
      {toastMessage && (
        <div className="fixed top-4 right-4 px-4 py-2 bg-green-50 border border-green-200 rounded text-sm text-green-700 z-50">
          {toastMessage}
        </div>
      )}

      {/* Alertas del equipo */}
      {teamAlerts.length > 0 && (
        <div className="card p-4">
          <h3 className="text-sm font-semibold mb-3">Alertas del equipo</h3>
          <div className="space-y-2">
            {teamAlerts.map((alert) => {
              const severityInfo = getAlertSeverityInfo(alert.severity)
              return (
                <div
                  key={alert.key}
                  className={`flex items-center gap-2 px-3 py-2 rounded text-sm ${severityInfo.bg} ${severityInfo.color}`}
                >
                  <span>{severityInfo.icon}</span>
                  <span>{alert.text}</span>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Resumen - Primera fila */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">Total Equipo</div>
          <div className="text-2xl font-black">{summary.total}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">Promedio Puntos</div>
          <div className="text-2xl font-black">{insights.avgPoints}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">Sin Actividad</div>
          <div className="text-2xl font-black text-red-600">{insights.noActivity}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">Ritmo Bajo</div>
          <div className="text-2xl font-black text-amber-600">{insights.lowRhythm}</div>
        </div>
      </div>

      {/* Resumen - Segunda fila */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">En riesgo</div>
          <div className="text-2xl font-black text-red-600">{summary.atRisk}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">En camino</div>
          <div className="text-2xl font-black text-green-600">{summary.onTrack}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">Cumplidos</div>
          <div className="text-2xl font-black text-green-600">{summary.completed}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">🔥</div>
          <div className="text-2xl font-black text-purple-600">{summary.excellent}</div>
        </div>
      </div>

      {/* Tabla Leaderboard Semanal */}
      <TeamWeeklyLeaderboardTable
        weekStats={weekStats}
        weeklyTarget={weeklyTarget}
        weeklyDays={weeklyDays}
        weekStartLocal={weekStartLocal}
        weekEndLocal={weekEndLocal}
        todayLocal={todayLocal}
        scoresMap={scoresMap}
        onAdvisorClick={handleAdvisorClick}
        defaultSort="points"
        getAdvisorName={getAdvisorName}
        getStatusInfo={getStatusInfo}
      />

      {/* Consistencia 12 semanas */}
      <TeamConsistencyTable
        historyStats={historyStats}
        weeklyTarget={weeklyTarget}
        getAdvisorName={getAdvisorName}
      />
    </div>
  )
}

/* 
 * INSTRUCCIONES DE PRUEBA MANUAL:
 * 
 * 1) INSIGHTS ACCIONABLES:
 *    - Verificar que cada fila muestra "Falta" y "Requiere/día"
 *    - Verificar badges de razón (Sin actividad / Ritmo bajo / En camino)
 *    - Verificar que los cards superiores muestran: Total, Promedio, Sin actividad, Ritmo bajo
 * 
 * 2) SORTING Y FILTROS:
 *    - Hacer clic en headers de tabla (Pts, Proyección, Estado, Requiere/día) para ordenar
 *    - Activar toggle "Solo en riesgo" y verificar que filtra correctamente
 * 
 * 3) NAVEGACIÓN A DETALLE:
 *    - Hacer clic en una fila de la tabla semanal
 *    - Debe navegar a /manager/advisor/:id
 *    - Verificar que la página de detalle muestra datos correctos
 *    - Verificar botón "Volver" funciona
 * 
 * 4) DEBUG SNAPSHOT (solo DEV):
 *    - Verificar que botón "Copiar snapshot" aparece solo en desarrollo
 *    - Hacer clic y verificar que se copia JSON al clipboard
 *    - Verificar que aparece toast "Snapshot copiado"
 * 
 * 5) CONSISTENCIA:
 *    - Verificar que tabla de consistencia está ordenada por promedio desc
 *    - Verificar que muestra badge "Consistente" cuando averagePoints >= weeklyTarget
 * 
 * 6) RESPONSIVE:
 *    - Verificar que tablas se adaptan en mobile/tablet
 *    - Verificar que cards se apilan correctamente
 * 
 * 7) QUÉ HACER HOY (columna "Hoy"):
 *    - Asesor con requiredDailyAvg > 0: debe mostrar plan (ej. "2 llamadas · 1 citas · 1 prop")
 *    - Asesor sin actividad (riskReason="no_activity"): debe mostrar kickstart (ej. "1 llamadas (Arranque)")
 *    - Asesor con requiredDailyAvg = 0: debe mostrar "✅" o "Mantener"
 *    - Hover sobre columna "Hoy" debe mostrar tooltip con desglose (requerido, distribución, omitidas)
 * 
 * 8) ALERTAS DEL EQUIPO:
 *    - Verificar que sección "Alertas del equipo" aparece arriba de las tablas
 *    - Verificar que muestra alertas relevantes (sin actividad, proyección baja, top 1, promedio, consistentes)
 *    - Verificar colores según severity (risk=rojo, warn=ámbar, good=verde, info=azul)
 */
