// TODO: Definir las claves de métricas según PROJECT_CONTEXT.md
export const METRIC_KEYS = {
  // calls, meetings_set, meetings_held, proposals_presented, applications_submitted, referrals, policies_paid
} as const
