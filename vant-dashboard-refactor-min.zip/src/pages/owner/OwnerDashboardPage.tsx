import { useState, useEffect, useMemo, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabaseClient'
import { okrQueries } from '../../modules/okr/data/okrQueries'
import { useUserRole } from '../../shared/hooks/useUserRole'
import { todayLocalYmd } from '../../shared/utils/dates'
import { getLastNWeekStarts } from '../../modules/okr/utils/weeklyHistoryHelpers'
import {
  buildScoresMap,
  calcWeekRangeLocal,
  computeAdvisorWeekStats,
  computeAdvisorHistoryStats,
  getScopedAdvisors,
  type Advisor,
  type AdvisorWeekStats,
  type AdvisorHistoryStats,
} from './utils/ownerDashboardHelpers'

type ProfileOption = {
  user_id: string
  full_name: string | null
  display_name: string | null
}

export function OwnerDashboardPage() {
  const navigate = useNavigate()
  const { isOwner, loading: roleLoading, error: roleError, retry: retryRole } = useUserRole()
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [weekStats, setWeekStats] = useState<AdvisorWeekStats[]>([])
  const [historyStats, setHistoryStats] = useState<AdvisorHistoryStats[]>([])
  const [dailyTarget, setDailyTarget] = useState(25)
  const [weeklyDays, setWeeklyDays] = useState(5)
  const [selectedManagerId, setSelectedManagerId] = useState<string | null>(null)
  const [selectedRecruiterId, setSelectedRecruiterId] = useState<string | null>(null)
  const [managers, setManagers] = useState<ProfileOption[]>([])
  const [recruiters, setRecruiters] = useState<ProfileOption[]>([])
  const mountedRef = useRef(true)

  const weeklyTarget = dailyTarget * weeklyDays
  const todayLocal = todayLocalYmd()
  const { weekStartLocal, weekEndLocal, nextWeekStartLocal } = calcWeekRangeLocal()

  // Cargar managers y recruiters para los dropdowns
  useEffect(() => {
    const loadFilters = async () => {
      try {
        const [managersRes, recruitersRes] = await Promise.all([
          supabase
            .from('profiles')
            .select('user_id, full_name, display_name')
            .in('role', ['manager', 'owner'])
            .order('full_name', { ascending: true, nullsFirst: false }),
          supabase
            .from('profiles')
            .select('user_id, full_name, display_name')
            .in('role', ['recruiter', 'owner'])
            .order('full_name', { ascending: true, nullsFirst: false }),
        ])

        if (mountedRef.current) {
          setManagers(managersRes.data || [])
          setRecruiters(recruitersRes.data || [])
        }
      } catch (err) {
        console.error('[OwnerDashboardPage] Error al cargar filtros:', err)
      }
    }

    if (isOwner && !roleLoading) {
      loadFilters()
    }
  }, [isOwner, roleLoading])

  const loadData = useCallback(async () => {
    if (!mountedRef.current) return
    
    setLoading(true)
    setError(null)
    
    try {
      // Obtener advisors en scope según filtros
      const scopedAdvisorIds = await getScopedAdvisors({
        managerId: selectedManagerId,
        recruiterId: selectedRecruiterId,
      })

      if (!mountedRef.current) return

      if (scopedAdvisorIds.length === 0) {
        if (mountedRef.current) {
          setWeekStats([])
          setHistoryStats([])
          setLoading(false)
        }
        return
      }

      // Query: Traer datos completos de advisors en scope
      const { data: advisorsData, error: advisorsError } = await supabase
        .from('profiles')
        .select('user_id, full_name, display_name, role')
        .in('user_id', scopedAdvisorIds)
        .order('full_name', { ascending: true, nullsFirst: false })
        .order('display_name', { ascending: true, nullsFirst: false })

      if (advisorsError) throw advisorsError

      const advisorsList: Advisor[] = (advisorsData || []).map((p) => ({
        user_id: p.user_id,
        full_name: p.full_name,
        display_name: p.display_name,
        role: p.role,
      }))

      if (!mountedRef.current) return

      const advisorIds = advisorsList.map((a) => a.user_id)

      // Query 2 y 3: Settings y scores globales
      const [settings, scores] = await Promise.all([
        okrQueries.getOkrSettingsGlobal(),
        okrQueries.getMetricScores(),
      ])

      setDailyTarget(settings.daily_base_target)
      setWeeklyDays(settings.weekly_days)
      const scoresMap = buildScoresMap(scores)

      // Query 4: Eventos de semana actual
      const [startYear, startMonth, startDay] = weekStartLocal.split('-').map(Number)
      const [nextYear, nextMonth, nextDay] = nextWeekStartLocal.split('-').map(Number)
      
      const weekStartUTC = new Date(Date.UTC(startYear, startMonth - 1, startDay, 0, 0, 0))
      const nextWeekUTC = new Date(Date.UTC(nextYear, nextMonth - 1, nextDay, 0, 0, 0))

      const { data: eventsWeek, error: eventsWeekError } = await supabase
        .from('activity_events')
        .select('recorded_at, metric_key, value, actor_user_id')
        .in('actor_user_id', advisorIds)
        .eq('is_void', false)
        .eq('source', 'manual')
        .gte('recorded_at', weekStartUTC.toISOString())
        .lt('recorded_at', nextWeekUTC.toISOString())
        .order('recorded_at', { ascending: true })

      if (eventsWeekError) throw eventsWeekError

      // Query 5: Eventos de últimas 12 semanas
      const weekStarts = getLastNWeekStarts(todayLocal, 12)
      const oldestWeekStart = weekStarts[weekStarts.length - 1]
      const [oldestYear, oldestMonth, oldestDay] = oldestWeekStart.split('-').map(Number)
      const oldestUTC = new Date(Date.UTC(oldestYear, oldestMonth - 1, oldestDay, 0, 0, 0))

      const { data: events12w, error: events12wError } = await supabase
        .from('activity_events')
        .select('recorded_at, metric_key, value, actor_user_id')
        .in('actor_user_id', advisorIds)
        .eq('is_void', false)
        .eq('source', 'manual')
        .gte('recorded_at', oldestUTC.toISOString())
        .lt('recorded_at', nextWeekUTC.toISOString())
        .order('recorded_at', { ascending: true })

      if (events12wError) throw events12wError

      // Calcular estadísticas semanales
      const weekStatsList: AdvisorWeekStats[] = []
      advisorsList.forEach((advisor) => {
        const stats = computeAdvisorWeekStats(
          eventsWeek || [],
          advisor.user_id,
          scoresMap,
          weeklyTarget,
          settings.weekly_days,
          todayLocal,
          weekStartLocal,
          weekEndLocal
        )
        if (stats) {
          stats.advisor = advisor
          weekStatsList.push(stats)
        } else {
          // Asesor sin actividad esta semana
          weekStatsList.push({
            advisor,
            weekPoints: 0,
            weekPointsUntilToday: 0,
            daysWithActivity: 0,
            currentRhythm: 0,
            projection: 0,
            percentOfTarget: 0,
            status: 'at_risk',
          })
        }
      })

      // Calcular estadísticas históricas
      const historyStatsList: AdvisorHistoryStats[] = []
      advisorsList.forEach((advisor) => {
        const stats = computeAdvisorHistoryStats(
          events12w || [],
          advisor.user_id,
          scoresMap,
          weeklyTarget
        )
        if (stats) {
          stats.advisor = advisor
          historyStatsList.push(stats)
        } else {
          // Asesor sin actividad histórica
          historyStatsList.push({
            advisor,
            weeksCompleted: 0,
            averagePoints: 0,
            bestWeek: 0,
          })
        }
      })

      // Ordenar por puntos desc
      weekStatsList.sort((a, b) => b.weekPoints - a.weekPoints)
      
      if (mountedRef.current) {
        setWeekStats(weekStatsList)
        setHistoryStats(historyStatsList)
      }
    } catch (err: unknown) {
      if (mountedRef.current) {
        const errorMessage = err instanceof Error ? err.message : 'Error al cargar datos'
        setError(errorMessage)
      }
    } finally {
      if (mountedRef.current) {
        setLoading(false)
      }
    }
  }, [weekStartLocal, weekEndLocal, nextWeekStartLocal, todayLocal, weeklyTarget, selectedManagerId, selectedRecruiterId])

  useEffect(() => {
    mountedRef.current = true
    
    if (!roleLoading && !isOwner) {
      navigate('/', { replace: true })
      return
    }
    
    if (isOwner && !roleLoading) {
      loadData()
    }

    return () => {
      mountedRef.current = false
    }
  }, [isOwner, roleLoading, navigate, loadData])

  // Calcular resumen de estados
  const summary = useMemo(() => {
    const atRisk = weekStats.filter((s) => s.status === 'at_risk').length
    const onTrack = weekStats.filter((s) => s.status === 'on_track').length
    const completed = weekStats.filter((s) => s.status === 'completed').length
    const excellent = weekStats.filter((s) => s.status === 'excellent').length
    
    return { atRisk, onTrack, completed, excellent, total: weekStats.length }
  }, [weekStats])

  // Obtener nombre del asesor
  const getAdvisorName = (advisor: Advisor): string => {
    if (advisor.full_name && advisor.full_name.trim()) {
      return advisor.full_name.trim()
    }
    if (advisor.display_name && advisor.display_name.trim()) {
      return advisor.display_name.trim()
    }
    return `Usuario ${advisor.user_id.slice(0, 8)}`
  }

  // Obtener nombre de perfil para filtros
  const getProfileName = (profile: ProfileOption): string => {
    if (profile.full_name && profile.full_name.trim()) {
      return profile.full_name.trim()
    }
    if (profile.display_name && profile.display_name.trim()) {
      return profile.display_name.trim()
    }
    return `Usuario ${profile.user_id.slice(0, 8)}`
  }

  // Obtener texto del scope actual
  const getScopeText = (): string => {
    if (selectedManagerId && selectedRecruiterId) {
      const manager = managers.find(m => m.user_id === selectedManagerId)
      const recruiter = recruiters.find(r => r.user_id === selectedRecruiterId)
      return `Equipo de ${getProfileName(manager!)} y reclutados por ${getProfileName(recruiter!)}`
    }
    if (selectedManagerId) {
      const manager = managers.find(m => m.user_id === selectedManagerId)
      return `Equipo de ${getProfileName(manager!)}`
    }
    if (selectedRecruiterId) {
      const recruiter = recruiters.find(r => r.user_id === selectedRecruiterId)
      return `Reclutados por ${getProfileName(recruiter!)}`
    }
    return 'Todos'
  }

  const handleClearFilters = () => {
    setSelectedManagerId(null)
    setSelectedRecruiterId(null)
  }

  // Obtener color y label del estado
  const getStatusInfo = (status: AdvisorWeekStats['status']) => {
    switch (status) {
      case 'excellent':
        return { label: '🔥', color: 'text-purple-600', bg: 'bg-purple-50' }
      case 'completed':
        return { label: '✅', color: 'text-green-600', bg: 'bg-green-50' }
      case 'on_track':
        return { label: 'En camino', color: 'text-green-600', bg: 'bg-green-50' }
      case 'at_risk':
        return { label: 'En riesgo', color: 'text-red-600', bg: 'bg-red-50' }
    }
  }

  if (roleLoading || loading) {
    return (
      <div className="text-center p-8">
        <span className="text-muted">Cargando...</span>
        {roleError === 'timeout' && !roleLoading && (
          <div className="mt-4">
            <button onClick={retryRole} className="btn btn-primary text-sm">
              Reintentar
            </button>
          </div>
        )}
      </div>
    )
  }

  if (!isOwner) {
    return (
      <div className="text-center p-8">
        <div className="text-lg font-semibold mb-2">No autorizado</div>
        <div className="text-sm text-muted">Solo el owner puede acceder a esta vista.</div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="card p-4 bg-red-50 border border-red-200">
        <div className="text-sm text-red-700">{error}</div>
        <button onClick={loadData} className="btn btn-primary mt-3 text-sm">
          Reintentar
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold mb-1">Dashboard Owner</h1>
        <p className="text-sm text-muted">Desempeño semanal y consistencia histórica de asesores</p>
      </div>

      {/* Filtros */}
      <div className="card p-4">
        <div className="flex flex-wrap items-end gap-4">
          <div className="flex-1 min-w-[200px]">
            <label className="block text-xs font-medium text-muted mb-1">Manager</label>
            <select
              value={selectedManagerId || ''}
              onChange={(e) => setSelectedManagerId(e.target.value || null)}
              className="w-full px-3 py-2 text-sm border border-border rounded bg-bg text-text"
            >
              <option value="">Todos</option>
              {managers.map((m) => (
                <option key={m.user_id} value={m.user_id}>
                  {getProfileName(m)}
                </option>
              ))}
            </select>
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="block text-xs font-medium text-muted mb-1">Recruiter</label>
            <select
              value={selectedRecruiterId || ''}
              onChange={(e) => setSelectedRecruiterId(e.target.value || null)}
              className="w-full px-3 py-2 text-sm border border-border rounded bg-bg text-text"
            >
              <option value="">Todos</option>
              {recruiters.map((r) => (
                <option key={r.user_id} value={r.user_id}>
                  {getProfileName(r)}
                </option>
              ))}
            </select>
          </div>
          {(selectedManagerId || selectedRecruiterId) && (
            <button
              onClick={handleClearFilters}
              className="px-4 py-2 text-sm border border-border rounded bg-bg text-text hover:bg-black/5 transition-colors"
            >
              Limpiar filtros
            </button>
          )}
        </div>
        <div className="mt-3 text-sm text-muted">
          Mostrando: <span className="font-medium text-text">{getScopeText()}</span>
        </div>
      </div>

      {/* Resumen */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">En riesgo</div>
          <div className="text-2xl font-black text-red-600">{summary.atRisk}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">En camino</div>
          <div className="text-2xl font-black text-green-600">{summary.onTrack}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">Cumplidos</div>
          <div className="text-2xl font-black text-green-600">{summary.completed}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">🔥</div>
          <div className="text-2xl font-black text-purple-600">{summary.excellent}</div>
        </div>
      </div>

      {/* Tabla Leaderboard Semanal */}
      <div className="card p-0 overflow-hidden">
        <div className="p-4 border-b border-border">
          <h2 className="text-lg font-semibold">Leaderboard Semanal</h2>
          <p className="text-xs text-muted mt-1">Semana actual: {weekStartLocal} - {weekEndLocal}</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-bg border-b border-border">
              <tr>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted uppercase">Asesor</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase">Pts</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase">%</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase">Proyección</th>
                <th className="text-center py-3 px-4 text-xs font-semibold text-muted uppercase">Estado</th>
              </tr>
            </thead>
            <tbody>
              {weekStats.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center py-12 px-4 text-muted">
                    No hay asesores registrados
                  </td>
                </tr>
              ) : (
                weekStats.map((stat) => {
                  const statusInfo = getStatusInfo(stat.status)
                  return (
                    <tr key={stat.advisor.user_id} className="border-b border-border hover:bg-bg">
                      <td className="py-3 px-4 font-medium">{getAdvisorName(stat.advisor)}</td>
                      <td className="py-3 px-4 text-right font-semibold">{Math.round(stat.weekPoints)}</td>
                      <td className="py-3 px-4 text-right text-muted">{Math.round(stat.percentOfTarget)}%</td>
                      <td className="py-3 px-4 text-right text-muted">
                        {stat.daysWithActivity > 0 ? Math.round(stat.projection) : '—'}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${statusInfo.bg} ${statusInfo.color}`}>
                          {statusInfo.label}
                        </span>
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Consistencia 12 semanas */}
      <div className="card p-0 overflow-hidden">
        <div className="p-4 border-b border-border">
          <h2 className="text-lg font-semibold">Consistencia 12 semanas</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-bg border-b border-border">
              <tr>
                <th className="text-left py-3 px-4 text-xs font-semibold text-muted uppercase">Asesor</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase">Cumplidas</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase">Promedio</th>
                <th className="text-right py-3 px-4 text-xs font-semibold text-muted uppercase">Mejor</th>
              </tr>
            </thead>
            <tbody>
              {historyStats.length === 0 ? (
                <tr>
                  <td colSpan={4} className="text-center py-12 px-4 text-muted">
                    No hay datos históricos
                  </td>
                </tr>
              ) : (
                historyStats.map((stat) => (
                  <tr key={stat.advisor.user_id} className="border-b border-border hover:bg-bg">
                    <td className="py-3 px-4 font-medium">{getAdvisorName(stat.advisor)}</td>
                    <td className="py-3 px-4 text-right">
                      <span className="font-semibold">{stat.weeksCompleted}</span>
                      <span className="text-muted"> / 12</span>
                    </td>
                    <td className="py-3 px-4 text-right font-medium">{stat.averagePoints} pts</td>
                    <td className="py-3 px-4 text-right font-medium">{stat.bestWeek} pts</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
