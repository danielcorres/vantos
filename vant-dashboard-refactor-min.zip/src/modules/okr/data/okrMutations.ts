// TODO: Implementar mutaciones para el módulo OKR
export const okrMutations = {
  // TODO: Agregar funciones de mutación (insert, update, delete)
}
