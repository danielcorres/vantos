import React, { useState, useMemo } from 'react'
import type { PipelineStage, Lead } from '../pipeline.api'
import { EmptyState } from '../../../components/pipeline/EmptyState'
import { InfoPopover } from '../../../shared/components/InfoPopover'
import { LeadCard } from './LeadCard'
import {
  sortLeadsByNextActionPriority,
  aggregateNextActionColumnCounts,
} from '../../../shared/utils/nextAction'
import { getStageHelp } from '../utils/stageHelp'
import { displayStageName } from '../../../shared/utils/stageStyles'

interface KanbanColumnProps {
  stage: PipelineStage
  stages: PipelineStage[]
  leads: Lead[]
  onDragStart: (e: React.DragEvent, lead: Lead) => void
  onDragOver: (e: React.DragEvent) => void
  onDrop: (e: React.DragEvent, stageId: string) => void
  onMoveStage?: (leadId: string, toStageId: string) => Promise<void>
  onToast?: (message: string) => void
  onUpdated?: () => void | Promise<void>
}

function KanbanColumnInner({
  stage,
  stages,
  leads,
  onDragStart,
  onDragOver,
  onDrop,
  onMoveStage,
  onToast,
  onUpdated,
}: KanbanColumnProps) {
  const [isDragOver, setIsDragOver] = useState(false)

  const sortedLeads = useMemo(() => sortLeadsByNextActionPriority(leads), [leads])
  const counts = useMemo(() => aggregateNextActionColumnCounts(leads), [leads])

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragOver(true)
    onDragOver(e)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragOver(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragOver(false)
    onDrop(e, stage.id)
  }

  return (
    <div
      className={`flex min-w-[280px] max-w-[280px] flex-col max-h-[calc(100vh-220px)] rounded-xl border border-neutral-200 bg-white shadow-sm transition-all duration-200 ${
        isDragOver
          ? 'ring-2 ring-primary/40 ring-inset bg-primary/5 border-primary/30'
          : ''
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <div className="sticky top-0 z-10 shrink-0 border-b border-neutral-200 bg-neutral-50/95 px-4 py-3 backdrop-blur-[2px]">
        <div className="mb-2 flex items-center gap-1.5">
          <span className="text-base font-semibold text-neutral-800">
            {displayStageName(stage.name)}
          </span>
          <InfoPopover
            title={getStageHelp(stage.slug ?? stage.name).title}
            bullets={getStageHelp(stage.slug ?? stage.name).bullets}
            tip={getStageHelp(stage.slug ?? stage.name).tip}
          />
        </div>
        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs">
          <span className="tabular-nums text-neutral-400">{counts.total} leads</span>
          {counts.overdue > 0 && (
            <span className="tabular-nums text-red-600 font-medium" title="Atrasados">
              {counts.overdue} atrasados
            </span>
          )}
          {counts.today > 0 && (
            <span className="tabular-nums text-emerald-600 font-medium" title="Hoy">
              {counts.today} hoy
            </span>
          )}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto min-h-[200px] p-2">
        {sortedLeads.length === 0 ? (
          <div className="py-4">
            <EmptyState title="Sin leads" variant="dashed" />
          </div>
        ) : (
          <div className="space-y-1.5">
            {sortedLeads.map((lead) => (
              <LeadCard
                key={lead.id}
                lead={lead}
                stages={stages}
                stageName={stage.name}
                onDragStart={onDragStart}
                onMoveStage={onMoveStage}
                onToast={onToast}
                onUpdated={onUpdated}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export const KanbanColumn = React.memo(KanbanColumnInner)
