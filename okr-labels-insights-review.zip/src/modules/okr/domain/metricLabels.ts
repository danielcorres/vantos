/**
 * Labels canónicos de métricas OKR
 * Única fuente de verdad para nombres de métricas en todo el sistema
 */

export const METRIC_LABELS: Record<string, string> = {
  calls: 'Llamadas',
  meetings_set: 'Citas agendadas',
  meetings_held: 'Citas realizadas',
  proposals_presented: 'Propuestas presentadas',
  applications_submitted: 'Solicitudes ingresadas',
  referrals: 'Referidos',
  policies_paid: 'Pólizas pagadas',
}

/**
 * Obtener label canónico de una métrica
 * @param metricKey Clave de la métrica (ej. 'calls', 'meetings_set')
 * @returns Label legible (ej. 'Llamadas', 'Citas agendadas') o la clave si no existe
 */
export function getMetricLabel(metricKey: string): string {
  return METRIC_LABELS[metricKey] || metricKey
}
