// TODO: Definir tipos TypeScript para el dominio OKR
export type MetricKey = string
export type ActivityEvent = {
  // TODO: Definir estructura según ARCHITECTURE.md
}
