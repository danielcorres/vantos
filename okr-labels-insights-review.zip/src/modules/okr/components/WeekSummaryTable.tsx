// TODO: Implementar componente WeekSummaryTable (tabla de resumen semanal)
export function WeekSummaryTable() {
  return null
}
