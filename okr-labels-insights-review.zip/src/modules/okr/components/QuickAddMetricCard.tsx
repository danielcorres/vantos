// TODO: Implementar componente QuickAddMetricCard (botón rápido para agregar métrica)
export function QuickAddMetricCard() {
  return null
}
