// TODO: Implementar componente UndoLastEventButton (botón para deshacer último evento)
export function UndoLastEventButton() {
  return null
}
