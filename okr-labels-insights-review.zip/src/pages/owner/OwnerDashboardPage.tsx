import { useState, useEffect, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabaseClient'
import { useUserRole } from '../../shared/hooks/useUserRole'
import { useTeamOkrDashboard } from '../../modules/okr/dashboard/useTeamOkrDashboard'
import { useDashboardSnapshot } from '../../modules/okr/dashboard/useDashboardSnapshot'
import { TeamWeeklyLeaderboardTable } from '../../modules/okr/components/TeamWeeklyLeaderboardTable'
import { TeamConsistencyTable } from '../../modules/okr/components/TeamConsistencyTable'
import { buildTeamAlerts, getAlertSeverityInfo } from '../../modules/okr/dashboard/teamAlerts'
import {
  type Advisor,
  type AdvisorWeekStats,
} from './utils/ownerDashboardHelpers'

const IS_DEV = import.meta.env.DEV

type ProfileOption = {
  user_id: string
  full_name: string | null
  display_name: string | null
}

export function OwnerDashboardPage() {
  const navigate = useNavigate()
  const { isOwner, loading: roleLoading, error: roleError, retry: retryRole } = useUserRole()
  const [selectedManagerId, setSelectedManagerId] = useState<string | null>(null)
  const [selectedRecruiterId, setSelectedRecruiterId] = useState<string | null>(null)
  const [managers, setManagers] = useState<ProfileOption[]>([])
  const [recruiters, setRecruiters] = useState<ProfileOption[]>([])

  // Usar hook compartido para datos del dashboard
  const {
    weekStats,
    historyStats,
    dailyTarget,
    weeklyDays,
    weeklyTarget,
    weekStartLocal,
    weekEndLocal,
    todayLocal,
    advisorIds,
    scoresMap,
    loading,
    error,
    reload: loadData,
  } = useTeamOkrDashboard({
    mode: 'owner',
    filters: {
      managerId: selectedManagerId,
      recruiterId: selectedRecruiterId,
    },
  })

  const { copySnapshot } = useDashboardSnapshot()
  const [toastMessage, setToastMessage] = useState<string | null>(null)

  // Calcular alertas del equipo
  const teamAlerts = useMemo(() => {
    return buildTeamAlerts({
      weekStats,
      historyStats,
      weeklyTarget,
    })
  }, [weekStats, historyStats, weeklyTarget])

  // Cargar managers y recruiters para los dropdowns
  useEffect(() => {
    const loadFilters = async () => {
      try {
        const [managersRes, recruitersRes] = await Promise.all([
          supabase
            .from('profiles')
            .select('user_id, full_name, display_name')
            .in('role', ['manager', 'owner'])
            .order('full_name', { ascending: true, nullsFirst: false }),
          supabase
            .from('profiles')
            .select('user_id, full_name, display_name')
            .in('role', ['recruiter', 'owner'])
            .order('full_name', { ascending: true, nullsFirst: false }),
        ])

        setManagers(managersRes.data || [])
        setRecruiters(recruitersRes.data || [])
      } catch (err) {
        console.error('[OwnerDashboardPage] Error al cargar filtros:', err)
      }
    }

    if (isOwner && !roleLoading) {
      loadFilters()
    }
  }, [isOwner, roleLoading])

  useEffect(() => {
    if (!roleLoading && !isOwner) {
      navigate('/', { replace: true })
    }
  }, [isOwner, roleLoading, navigate])

  // Calcular resumen de estados
  const summary = useMemo(() => {
    const atRisk = weekStats.filter((s) => s.status === 'at_risk').length
    const onTrack = weekStats.filter((s) => s.status === 'on_track').length
    const completed = weekStats.filter((s) => s.status === 'completed').length
    const excellent = weekStats.filter((s) => s.status === 'excellent').length
    
    return { atRisk, onTrack, completed, excellent, total: weekStats.length }
  }, [weekStats])

  // Obtener nombre del asesor
  const getAdvisorName = (advisor: Advisor): string => {
    if (advisor.full_name && advisor.full_name.trim()) {
      return advisor.full_name.trim()
    }
    if (advisor.display_name && advisor.display_name.trim()) {
      return advisor.display_name.trim()
    }
    return `Usuario ${advisor.user_id.slice(0, 8)}`
  }

  // Obtener nombre de perfil para filtros
  const getProfileName = (profile: ProfileOption): string => {
    if (profile.full_name && profile.full_name.trim()) {
      return profile.full_name.trim()
    }
    if (profile.display_name && profile.display_name.trim()) {
      return profile.display_name.trim()
    }
    return `Usuario ${profile.user_id.slice(0, 8)}`
  }

  // Obtener texto del scope actual
  const getScopeText = (): string => {
    if (selectedManagerId && selectedRecruiterId) {
      const manager = managers.find(m => m.user_id === selectedManagerId)
      const recruiter = recruiters.find(r => r.user_id === selectedRecruiterId)
      return `Equipo de ${getProfileName(manager!)} y reclutados por ${getProfileName(recruiter!)}`
    }
    if (selectedManagerId) {
      const manager = managers.find(m => m.user_id === selectedManagerId)
      return `Equipo de ${getProfileName(manager!)}`
    }
    if (selectedRecruiterId) {
      const recruiter = recruiters.find(r => r.user_id === selectedRecruiterId)
      return `Reclutados por ${getProfileName(recruiter!)}`
    }
    return 'Todos'
  }

  const handleClearFilters = () => {
    setSelectedManagerId(null)
    setSelectedRecruiterId(null)
  }

  const handleAdvisorClick = (advisorId: string) => {
    navigate(`/manager/advisor/${advisorId}`)
  }

  const handleCopySnapshot = async () => {
    const success = await copySnapshot(
      'owner',
      weekStartLocal,
      weekEndLocal,
      weeklyTarget,
      dailyTarget,
      weeklyDays,
      advisorIds
    )
    if (success) {
      setToastMessage('Snapshot copiado')
      setTimeout(() => setToastMessage(null), 2000)
    }
  }

  // Obtener color y label del estado
  const getStatusInfo = (status: AdvisorWeekStats['status']) => {
    switch (status) {
      case 'excellent':
        return { label: '🔥', color: 'text-purple-600', bg: 'bg-purple-50' }
      case 'completed':
        return { label: '✅', color: 'text-green-600', bg: 'bg-green-50' }
      case 'on_track':
        return { label: 'En camino', color: 'text-green-600', bg: 'bg-green-50' }
      case 'at_risk':
        return { label: 'En riesgo', color: 'text-red-600', bg: 'bg-red-50' }
    }
  }

  if (roleLoading || loading) {
    return (
      <div className="text-center p-8">
        <span className="text-muted">Cargando...</span>
        {roleError === 'timeout' && !roleLoading && (
          <div className="mt-4">
            <button onClick={retryRole} className="btn btn-primary text-sm">
              Reintentar
            </button>
          </div>
        )}
      </div>
    )
  }

  if (!isOwner) {
    return (
      <div className="text-center p-8">
        <div className="text-lg font-semibold mb-2">No autorizado</div>
        <div className="text-sm text-muted">Solo el owner puede acceder a esta vista.</div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="card p-4 bg-red-50 border border-red-200">
        <div className="text-sm text-red-700">{error}</div>
        <button onClick={loadData} className="btn btn-primary mt-3 text-sm">
          Reintentar
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold mb-1">Dashboard Owner</h1>
          <p className="text-sm text-muted">Desempeño semanal y consistencia histórica de asesores</p>
        </div>
        {IS_DEV && (
          <button
            onClick={handleCopySnapshot}
            className="px-3 py-1.5 text-xs border border-border rounded bg-bg text-text hover:bg-black/5 transition-colors"
          >
            Copiar snapshot
          </button>
        )}
      </div>

      {/* Toast para snapshot */}
      {toastMessage && (
        <div className="fixed top-4 right-4 px-4 py-2 bg-green-50 border border-green-200 rounded text-sm text-green-700 z-50">
          {toastMessage}
        </div>
      )}

      {/* Alertas del equipo */}
      {teamAlerts.length > 0 && (
        <div className="card p-4">
          <h3 className="text-sm font-semibold mb-3">Alertas del equipo</h3>
          <div className="space-y-2">
            {teamAlerts.map((alert) => {
              const severityInfo = getAlertSeverityInfo(alert.severity)
              return (
                <div
                  key={alert.key}
                  className={`flex items-center gap-2 px-3 py-2 rounded text-sm ${severityInfo.bg} ${severityInfo.color}`}
                >
                  <span>{severityInfo.icon}</span>
                  <span>{alert.text}</span>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Filtros */}
      <div className="card p-4">
        <div className="flex flex-wrap items-end gap-4">
          <div className="flex-1 min-w-[200px]">
            <label className="block text-xs font-medium text-muted mb-1">Manager</label>
            <select
              value={selectedManagerId || ''}
              onChange={(e) => setSelectedManagerId(e.target.value || null)}
              className="w-full px-3 py-2 text-sm border border-border rounded bg-bg text-text"
            >
              <option value="">Todos</option>
              {managers.map((m) => (
                <option key={m.user_id} value={m.user_id}>
                  {getProfileName(m)}
                </option>
              ))}
            </select>
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="block text-xs font-medium text-muted mb-1">Recruiter</label>
            <select
              value={selectedRecruiterId || ''}
              onChange={(e) => setSelectedRecruiterId(e.target.value || null)}
              className="w-full px-3 py-2 text-sm border border-border rounded bg-bg text-text"
            >
              <option value="">Todos</option>
              {recruiters.map((r) => (
                <option key={r.user_id} value={r.user_id}>
                  {getProfileName(r)}
                </option>
              ))}
            </select>
          </div>
          {(selectedManagerId || selectedRecruiterId) && (
            <button
              onClick={handleClearFilters}
              className="px-4 py-2 text-sm border border-border rounded bg-bg text-text hover:bg-black/5 transition-colors"
            >
              Limpiar filtros
            </button>
          )}
        </div>
        <div className="mt-3 text-sm text-muted">
          Mostrando: <span className="font-medium text-text">{getScopeText()}</span>
        </div>
      </div>

      {/* Resumen */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">En riesgo</div>
          <div className="text-2xl font-black text-red-600">{summary.atRisk}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">En camino</div>
          <div className="text-2xl font-black text-green-600">{summary.onTrack}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">Cumplidos</div>
          <div className="text-2xl font-black text-green-600">{summary.completed}</div>
        </div>
        <div className="card p-4">
          <div className="text-xs text-muted mb-1">🔥</div>
          <div className="text-2xl font-black text-purple-600">{summary.excellent}</div>
        </div>
      </div>

      {/* Tabla Leaderboard Semanal */}
      <TeamWeeklyLeaderboardTable
        weekStats={weekStats}
        weeklyTarget={weeklyTarget}
        weeklyDays={weeklyDays}
        weekStartLocal={weekStartLocal}
        weekEndLocal={weekEndLocal}
        todayLocal={todayLocal}
        advisorIds={advisorIds}
        scoresMap={scoresMap}
        onAdvisorClick={handleAdvisorClick}
        defaultSort="points"
        getAdvisorName={getAdvisorName}
        getStatusInfo={getStatusInfo}
      />

      {/* Consistencia 12 semanas */}
      <TeamConsistencyTable
        historyStats={historyStats}
        weeklyTarget={weeklyTarget}
        getAdvisorName={getAdvisorName}
      />
    </div>
  )
}
